//Mouse over text
document.getElementById("textchange").addEventListener("mouseover", mouseOver);
document.getElementById("textchange").addEventListener("mouseout", mouseOut);

function mouseOver() {
  document.getElementById("textchange").style.color = "pink";
}

function mouseOut() {
  document.getElementById("textchange").style.color = "black";
}

//Click on buttons
function myFunction() {
  document.getElementById("button").innerHTML = "Ticket bought!";
}
function myFunction2() {
  document.getElementById("button-not").innerHTML = "Ticket not available!";
}

//Double click
function myFunction3() {
  document.getElementById("double1").innerHTML = "Romeo and Juliet";
}
function myFunction4() {
  document.getElementById("double2").innerHTML = "Don Quixote";
}
function myFunction5() {
  document.getElementById("double3").innerHTML = "Dance with The Royal Ballet";
}

//Page Load
function myFunction6() {
  alert("Page is loaded");
}

//Copy
document.getElementById("copy").addEventListener("copy", myFunction7);

function myFunction7() {
  alert("You copied text!");
}

//Resize the social media icons on mouse over
function bigImg(x) {
  x.style.height = "64px";
  x.style.width = "64px";
}

function normalImg(x) {
  x.style.height = "32px";
  x.style.width = "32px";
}

//Output the coordinates of the mouse pointer when the mouse button is clicked on the header picture
function showCoords(event) {
  var x = event.clientX;
  var y = event.clientY;
  var coords = "X coords: " + x + ", Y coords: " + y;
  document.getElementById("demo").innerHTML = coords;
}